cd ../ && zip -r Platformer.love Platformer && love Platformer.love

